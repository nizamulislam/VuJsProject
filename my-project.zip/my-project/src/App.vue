<template>
  <div id="all">
    
      <!-- Header -->
      <header id="header">
        <div class="inner">
          <a href="index.html" class="logo"><strong>Projection</strong> by TEMPLATED</a>
          <nav id="nav">


          <router-link to="/" exact>Home</router-link>
             <router-link to="/generic">Generic</router-link>
                <router-link to="/element">Element</router-link>
           
          </nav>
          <a href="#navPanel" class="navPanelToggle"><span class="fa fa-bars"></span></a>
        </div>
      </header>





<!-- Banner -->
      <section id="banner">
        <div class="inner">
          <header>
            <h1>Welcome to Projection</h1>
          </header>

          <div class="flex ">

            <div>
              <span class="icon fa-car"></span>
              <h3>Aliquam</h3>
              <p>Suspendisse amet ullamco</p>
            </div>

            <div>
              <span class="icon fa-camera"></span>
              <h3>Elementum</h3>
              <p>Class aptent taciti ad litora</p>
            </div>

            <div>
              <span class="icon fa-bug"></span>
              <h3>Ultrices</h3>
              <p>Nulla vitae mauris non felis</p>
            </div>

          </div>

          <footer>
            <a href="#" class="button">Get Started</a>
          </footer>
        </div>
      </section>





    <div id="my_content">
      <router-view>
      </router-view>

    </div>





    







    <!-- Footer -->
      <footer id="footer">
        <div class="inner">

          <h3>Get in touch</h3>

          <form action="#" method="post">

            <div class="field half first">
              <label for="name">Name</label>
              <input name="name" id="name" type="text" placeholder="Name">
            </div>
            <div class="field half">
              <label for="email">Email</label>
              <input name="email" id="email" type="email" placeholder="Email">
            </div>
            <div class="field">
              <label for="message">Message</label>
              <textarea name="message" id="message" rows="6" placeholder="Message"></textarea>
            </div>
            <ul class="actions">
              <li><input value="Send Message" class="button alt" type="submit"></li>
            </ul>
          </form>

          <div class="copyright">
            &copy; Untitled. Design: <a href="https://templated.co">TEMPLATED</a>. Images: <a href="https://unsplash.com">Unsplash</a>.
          </div>

        </div>
      </footer>
  </div>
</template>

<script>

import VueRouter from 'vue-router'


import Home from './mypages/Home.vue'
import Generic from './mypages/Generic.vue'
import Element from './mypages/Element.vue'





const routes = [
  { path: '/', component: Home },
  { path: '/generic', component: Generic },
   { path: '/element', component: Element }
]


const router = new VueRouter({
 routes:routes,
 mode:'history'
})











export default {
  name: 'all',
  data () {
    return {
      msg: 'Welcome to Your Vue.js App',
      name:"Atik"
    }
  },

  router

  
}
</script>

<style>
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}

h1, h2 {
  font-weight: normal;
}

ul {
  list-style-type: none;
  padding: 0;
}

li {
  display: inline-block;
  margin: 0 10px;
}

a {
  color: #42b983;
}
</style>
