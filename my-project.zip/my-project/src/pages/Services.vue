<template>
   <div class="content" align="center" id="welcome">
   <h1>This is ServicesPage</h1>
      <div class="left-content">
       <div class="content_image">
          <img src="/dist/images/teacher1.jpg" alt="image">
       </div>
       
       <p>
       simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset s
       </p>
    </div>
      <div class="middle-content">
       <div class="content_image">
          <img src="/dist/images/teacher2.jpg" alt="image">
       </div>
       
       <p>
       simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset s
       </p>
    </div>
      <div class="right-content" align="center">
           <h4>Notice Board</h4>
         <marquee direction="up" scrollamount='2'>
            <ul>
    <li><a href=""> simply dummy text of the printing</a></li>
    <li><a href=""> simply dummy text of the printing</a></li>
    <li><a href=""> simply dummy text of the printing</a></li>
    <li><a href=""> simply dummy text of the printing</a></li>
    
    </ul>
    </marquee>
         
         
    </div>
   
   </div>

</template>