<?php
 $con=mysqli_connect('localhost','root','','vuecrud');
 if($con->connect_error){
 	die('CouldNot connect to Database');
 }

 $res=array('error'=>false);

 $action="read";

 if(isset($_GET['action']))
 {
 	$action=$_GET['action'];
 }

 if($action=="read")
 {
 	$result=$con->query("select * from users");
 	$users=array();

 	while($row=mysqli_fetch_assoc($result)){
 		array_push($users,$row);
 	}
 	$res['users']=$users;
 }





 if($action=="create")
 {

 	$name=$_POST['username'];
 	$email=$_POST['email'];
 	$mobile=$_POST['mobile'];
 	$result=$con->query("insert into users(username,email,mobile) values('$name','$email','$mobile')");
   if($result)
   {
 	$res['users']="User Added Successfully";
   }

   else
   {
   	 $res['error']=true;
     $res['users']="Could Not Inserted";
    }
 	
 }




 if($action=="update")
 {
    $id=$_POST['id'];
 	$name=$_POST['username'];
 	$email=$_POST['email'];
 	$mobile=$_POST['mobile'];
 	$result=$con->query("update users set username='$name',email='$email',mobile='$mobile' where id='$id'");
   if($result)
   {
 	$res['users']="User Updated Successfully";
   }

   else
   {
   	 $res['error']=true;
     $res['users']="Could Not Updated";
    }
 	
 }




if($action=="delete")
 {
    $id=$_POST['id'];
 	
 	$result=$con->query("delete from users where id='$id'");
   if($result)
   {
 	$res['users']="User Deleted Successfully";
   }

   else
   {
   	 $res['error']=true;
     $res['users']="Could Not Updated";
    }
 	
 }











 $con->close();
 header("Content-type:application/json");
 echo json_encode($res);
 die();
?>